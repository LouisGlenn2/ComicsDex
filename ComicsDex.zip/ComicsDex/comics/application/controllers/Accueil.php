<?php
    class Accueil extends CI_Controller{
        public function __construct(){
            parent::__construct();
            $this->load->model('CreerCompte');
            $this->load->model('Model_Afficher_liste_comics');
            $this->load->model('Model_Connection');
            $this->load->model('Model_profil');
            $this->load->model('Model_administration');
            
            $this->load->library('session');
            $this->load->helper('url');
        }
        
        public function index(){
            $data['content'] = 'accueil';
            $this->load->helper('form');
            $this->load->library('form_validation');
            $this->load->vars($data);
            $this->load->view('template');
        }
       public function creer(){
            $this->load->helper('html');
            $this->load->helper('url');
            $this->load->helper('form');
            $this->load->library('form_validation');
            $this->load->view('formCompte');     
        }
      
        public function inscrire(){
                $data['title'] = 'Creer un compte';
                $this->load->helper('form');
                $this->load->library('form_validation');
                $this->form_validation->set_rules('login', 'LOGIN', 'required');
                $this->form_validation->set_rules('name', 'NAME', 'required');
                $this->form_validation->set_rules('firstname', 'FIRSTNAME', 'required');
                $this->form_validation->set_rules('password', 'PASSWORD', 'required');
                $this->form_validation->set_rules('password2', 'PASSWORD2', 'required|matches[password]');

                $login = $this->input->post('login');
                $name = $this->input->post('name');
                $firstname = $this->input->post('firstname');
                $password = $this->input->post('password');
                $password2 = $this->input->post('password2');

                    if(!($this->form_validation->run() == FALSE )){
                        if(!$this->CreerCompte->existe($login)){
                            $data['content'] = 'form';
                            $password=crc32($password);
                            $this->CreerCompte->formInscription($login, $name, $firstname, $password);
                            redirect('accueil/connection');
                        }else{
                            $this->load->view('formCompte');
                            echo 'proble';
                        }
                   }else{
                        $this->load->view('formCompte');

                    }
        }

        public function connection(){
            $this->load->helper('form');
            $this->load->library('form_validation');
            $this->load->view('formConnection');
        }
        
        public function connecter(){
            $this->load->helper('form');
            $this->load->library('form_validation');
            $this->form_validation->set_rules('login', 'LOGIN', 'required');
            $this->form_validation->set_rules('password', 'PASSWORD', 'required');
            if(!($this->form_validation->run() == FALSE )){
                $login = $this->input->post('login');
                $password = $this->input->post('password');
                if($this->Model_Connection->verification($login, $password) == 1){
                    $info_user=array('login'=>$login,'password' => $password);
                    $this->session->set_userdata($info_user);
                    redirect('accueil/profil');
                }else{
                    redirect('Accueil/index');
                   //this->load->view('formConnection');
                }  
            }else{
                    $this->load->view('formConnection');

            }
        }
        
        public function deconnexion(){
            $this->load->helper('form');
            $this->load->library('form_validation');
            $this->session->sess_destroy();
            redirect('accueil/connection');
        }
        public function pageAjouterComics(){
            $this->load->helper('html');
            $this->load->helper('form');
            $data['comic'] = $this->Model_Afficher_liste_comics->get_comics($this->session->userdata('login'));
            $data['comics'] = 'Liste des comics';
            $data['content'] = 'liste';
            $this->load->vars($data);
            $this->load->view('liste');
        }
                
          public function profil(){
            $this->load->helper('form');
            $this->load->helper('html');
            if($this->session->userdata('login')!= false){
                $data['comic'] = $this->Model_profil->get_mesComics($this->session->userdata('login'));
                $data['comics'] = 'Liste des comics';
                $data['content'] = 'liste';
                $this->load->vars($data);
                $this->load->view('profil');
            }else{
                $this->inscrire();
            }
        }
        
        public function supprimerComics(){
            $this->load->helper('html');
            $this->load->helper('form');
            $data['comic_id']= '$comic_id';
            $comic_id = $this->input->post('comic_id');
            $this->Model_profil->suppComics($comic_id, $this->session->userdata('login'));
            $this->load->vars($data);
            redirect('accueil/profil');
            //$this->load->view('confirmation');
        }
        public function ajouterComics(){
            $data['comic_id']= '$comic_id';
            $comic_id = $this->input->post('comic_id');
            $data['login']='login';
            $login = $this->input->post('login');
            $this->Model_Afficher_liste_comics->add_comics($this->session->userdata('login'), $comic_id);
            redirect('accueil/profil');
        }
        
        public function adminAfficherUser(){
            $this->load->helper('html');
            $this->load->helper('form');
            $data['user'] = $this->Model_administration->afficher_user();
            $data['users'] = 'Liste des utilisateurs';
            $data['content'] = 'liste';
            $this->load->vars($data);
            $this->load->view('listeUser');
        }
        
        public function adminSupprimerUser(){
            $this->load->helper('html');
            $this->load->helper('form');
            $data['login']= 'login';
            $login = $this->input->post('login');
            $this->Model_administration->ban_user($login);
            redirect('accueil/adminAfficherUser');
        }
    }
?>
