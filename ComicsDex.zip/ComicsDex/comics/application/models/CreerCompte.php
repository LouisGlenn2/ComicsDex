<?php

    class CreerCompte extends CI_Model{
        public function __construct(){
            $this->load->database();
        }
    
    public function existe($login){
        $query = $this->db->select('*')->from('_collector')->where('login',$login)->get()->result_array();
        return (count($query) === 1);
    }
        
    public function formInscription($login, $name, $firstname, $password){
            $data = array(
                'login' => $login,
                'name' => $name,
                'firstname' => $firstname,
                'password' => $password
            );
            
            return $this->db->insert('_collector', $data);
        }
    }
?>
