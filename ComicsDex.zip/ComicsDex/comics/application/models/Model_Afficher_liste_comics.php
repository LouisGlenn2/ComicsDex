<?php

    class Model_Afficher_liste_comics extends CI_Model{
        public function __construct(){
            $this->load->database();
        }
    
        public function get_comics($login){
        //    $query = $this->db->get('_comic');
       //     return $query->result_array();
            return $this->db->query("select * from comics._comic EXCEPT SELECT comics._comic.comic_id, comics._comic.serie, comics._comic.numero,comics._comic.date,comics._comic.couverture from comics._collect  inner join comics._comic on comics._collect.comic_id = comics._comic.comic_id where comics._collect.collector_login = '$login' order by comic_id")->result_array();
        }
        
        public function plusRecent($login){
                 return $this->db->select('_collect.comic_id')->from('_collect')->join('_comic','_comic.comic_id = _collect.comic_id')->where('collector_login',$login)->order_by('date')->limit(1)->get()->result_array();
        }
        public function add_comics($login, $comic_id){
            if(count($this->Model_profil->nb_comics($login)) >= 10){
                $plusrecent=$this->Model_Afficher_liste_comics->plusRecent($login)[0]['comic_id'];
                $this->Model_profil->suppComics($plusrecent,$login);
            }
                $data = array('comic_id'=> $comic_id,'collector_login'=> $login);
                return $this->db->insert('_collect', $data);        
        }
    }
?>
