<?php

    class Model_Connection extends CI_Model{
        public function __construct(){
            $this->load->database();
        }
    
        public function verification($login, $password){
            $password=crc32($password);
           // $data=array('login'=>$login, 'password'=>$password2);
            //$query = $this->db->select('*')->from('_collector')->where($data)->get()->result_array();
            $query =$this->db->query("select * from comics._collector where login = '$login' and password = '$password';")->result_array();
            return (count($query));
            
        }
         

    }
?>