<?php

    class Model_Principal extends CI_Model{
        public function __construct(){
            $this->load->database();
    }
    //partie profil
    //affiche les comics de l'utilisateur
    public function get_mesComics($login){
        $query = $this->db->select('*')->from('_collect')->join('_comic','_collect.comic_id=_comic.comic_id')->where('collector_login',$login)->order_by('date desc')->get();
        return $query->result_array();
    }
    //permet de supprimer un comic de sa liste
    public function suppComics($comic_id, $login){
        $this->db->query("DELETE FROM comics._collect WHERE collector_login ='$login' AND comic_id ='$comic_id';");
    }
    //permet de calculer le nombre de comics de l'utilisateur
    public function nb_comics($login){
        $query = $this->db->select('*')->from('_collect')->join('_comic','_collect.comic_id=_comic.comic_id')->where('collector_login',$login)->order_by('date')->get();
        return $query->result_array();
    }
    //Partie ajout/liste des comics
    //Affiche l'ensemble des comics  
    public function get_comics($login){
            return $this->db->query("select * from comics._comic EXCEPT SELECT comics._comic.comic_id, comics._comic.serie, comics._comic.numero,comics._comic.date,comics._comic.couverture from comics._collect  inner join comics._comic on comics._collect.comic_id = comics._comic.comic_id where comics._collect.collector_login = '$login' order by comic_id")->result_array();
    }
        
    public function plusRecent($login){
            return $this->db->select('_collect.comic_id')->from('_collect')->join('_comic','_comic.comic_id = _collect.comic_id')->where('collector_login',$login)->order_by('date')->limit(1)->get()->result_array();
    }
    //Permet d'ajouter un comics
    public function add_comics($login, $comic_id){
         if(count($this->Model_Principal->nb_comics($login)) >= 10){
            $plusrecent=$this->Model_Principal->plusRecent($login)[0]['comic_id'];
             $this->Model_Principal->suppComics($plusrecent,$login);
         }
        $data = array('comic_id'=> $comic_id,'collector_login'=> $login);
        return $this->db->insert('_collect', $data);        
    }   
    //partie admin   
    //affiche la liste des utilisateurs 
    public function afficher_user(){
            return $this->db->query("select * from comics._collector EXCEPT SELECT * from comics._collector where login = 'admin';")->result_array();
    }
    //supprime les données d'un utilisateur
    public function ban_user($login){
            $data = array('login' => $login);
            $dataB = array('collector_login'=> $login);
            $this->db->delete('_collect', $dataB);
            $this->db->delete('_collector', $data);
    }    
    //partie connexion
    //Verifie si le mdp et le login correspondent
    public function verification($login, $password){
            $password=crc32($password);
            $query = $this->db->select('*')->from('_collector')->where('login',$login, 'password', $password)->get()->result_array();
            return (count($query));  
    } 
    //partie inscription
    //Verifie que le compte existe
    public function existe($login){
        $query = $this->db->select('*')->from('_collector')->where('login',$login)->get()->result_array();
        return (count($query) === 1);
    }
    //insert le nouveau compte
    public function formInscription($login, $name, $firstname, $password){
            $data = array(
                'login' => $login,
                'name' => $name,
                'firstname' => $firstname,
                'password' => $password
            );
            
            return $this->db->insert('_collector', $data);
        }
        
    public function get_comicsVisiteur(){
            return $this->db->query("select * from comics._comic order by comic_id")->result_array();

    }
    }
?>