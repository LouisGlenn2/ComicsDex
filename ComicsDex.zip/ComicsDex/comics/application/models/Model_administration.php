<?php
    class Model_administration extends CI_Model{
        public function __construct(){
            $this->load->database();
        }
        
        public function afficher_user(){
            return $this->db->query("select * from comics._collector EXCEPT SELECT * from comics._collector where login = 'admin';")->result_array();
        }
        
        public function ban_user($login){
            $data = array('login' => $login);
            $dataB = array('collector_login'=> $login);
            $this->db->delete('_collect', $dataB);
            $this->db->delete('_collector', $data);
        }
    }
?>