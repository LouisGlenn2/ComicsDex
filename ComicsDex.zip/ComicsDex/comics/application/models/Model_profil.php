<?php

    class Model_profil extends CI_Model{
        public function __construct(){
            $this->load->database();
        }
    
        public function get_mesComics($login){
            $query = $this->db->select('*')->from('_collect')->join('_comic','_collect.comic_id=_comic.comic_id')->where('collector_login',$login)->order_by('date')->get();
            return $query->result_array();
        }
        
        public function suppComics($comic_id, $login){
            $this->db->query("DELETE FROM comics._collect WHERE collector_login ='$login' AND comic_id ='$comic_id';");
        }
        
        public function nb_comics($login){
            $query = $this->db->select('*')->from('_collect')->join('_comic','_collect.comic_id=_comic.comic_id')->where('collector_login',$login)->order_by('date')->get();
           
            return $query->result_array();
        }
    }
?>
