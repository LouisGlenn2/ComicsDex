<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <link href="<?php echo base_url();?>application/views/bootstrap/css/bootstrap.min.css" rel="stylesheet">
        <script src="<?php echo base_url();?>application/views/bootstrap/js/bootstrap.min.js"></script>
        <link rel="stylesheet" type="text/css" href="<?php echo base_url();?>application/views/style.css">
        <title>Accueil</title>
    </head>
        <body class="row justify-content-center container-fluid">
          
            <main class="row justify-content-center">
                <div class="menu">
                    <h1>Comics Collection </h1>
			        <h2>Bienvenue sur notre site de collection de comics !</h2>
                    <div>
                        <div>
                            <?php echo validation_errors(); ?>
                            <?php echo form_open('accueil/connection') ?>
                            <input type="submit" action="<?php echo base_url('accueil/connection'); ?>" value="CONNEXION" />
                            <?php echo form_close(); ?>
                        </div>
                        <div>
                            <?php echo form_open('accueil/creer') ?>
                            <input type="submit" action="<?php echo base_url('accueil/creer'); ?>" value="CREER UN COMPTE" />
                            <?php echo form_close(); ?>
                        </div>       
                        
                    </div>
                    
                </div>
                
            </main>

        </body>
</html>

