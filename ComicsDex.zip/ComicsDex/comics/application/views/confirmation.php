<div>
    <?php echo validation_errors(); ?>
    <?php echo form_open('accueil/profil') ?>
    <input type="submit" value="confirmer" />
    <?php echo form_close(); ?>
</div>