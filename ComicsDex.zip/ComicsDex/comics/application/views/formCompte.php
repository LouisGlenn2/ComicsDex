<h2>Créer un compte</h2>


<?php echo validation_errors(); ?>
<?php echo form_open('accueil/index') ?>
    <input type="submit" value="Accueil" />
    <?php echo form_close(); ?>
    
<?php echo form_open('Accueil/inscrire')?>
    <label for="login">login :</label>
    <input type="input" name="login" /><br/>
    <label for="name">name :</label>
    <input type="input" name="name" /><br/>
    <label for="firstname">firstname :</label>
    <input type="input" name="firstname" /><br/>
    <label for="password">password :</label>
    
    <input type="password" name="password" /><br/>
    <label for="password">Confirmer password :</label>
    <input type="password" name="password2" /><br/>
    <input type="submit" name="submit" value="Créer un compte"/>
<?php echo form_close(); ?>


