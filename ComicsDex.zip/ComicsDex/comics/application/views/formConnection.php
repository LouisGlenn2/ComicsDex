<h2>Connection</h2>

<?php echo validation_errors(); ?>
<div>
    <?php echo form_open('accueil/index') ?>
    <input type="submit" value="Accueil" />
    <?php echo form_close(); ?>
</div>
<div>
<?php echo form_open('Accueil/connecter')?>
    <label for="login">login :</label>
    <input type="input" name="login" /><br/>
    <label for="password">Password :</label>
    <input type="password" name="password" /><br/>
    <input type="submit" name="submit" value="Connexion"/>
<?php echo form_close(); ?>


