<div>
    <?php echo form_open('accueil/profil') ?>
    <input type="submit" value="<- retour" />
    <?php echo form_close(); ?>
</div>
<ul>
    <?php foreach ($comic as $todo_item): ?>
        <?php 
            echo '<li> ';
            echo form_open('accueil/ajouterComics');
            echo $todo_item['comic_id']." ".$todo_item['serie']." ".$todo_item['numero']." ".$todo_item['date']." ".'<img class="photo" src="'.$todo_item['couverture'].'"/></li>'; ?>
            <input type="hidden" name="comic_id" value="<?php echo $todo_item['comic_id'] ?>">
            <input type="submit" value="Ajouter" />
            <?php echo form_close(); ?>
            <?php echo '</li>'; ?>
            
    <?php endforeach ?>
</ul>

<style>
    .photo{
        width: 100px;
        height: 200px;
    }
</style>
