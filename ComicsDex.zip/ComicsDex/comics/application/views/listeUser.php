<div>
    <?php echo form_open('accueil/profil') ?>
    <input type="submit" value="<- retour" />
    <?php echo form_close(); ?>
</div>
<div>
   <ul> 
        <?php foreach($user as $item): ?>
           <?php
            echo '<li>';
            echo form_open('accueil/adminSupprimerUser');
            echo 'login : '.$item['login'].' name : '.$item['name'].' firstname : '.$item['firstname']; ?>
            <input type="hidden" name="login" value="<?php echo $item['login'] ?>">
            <input type="submit" value="Bannir" />
            <?php echo form_close(); 
                  echo '</li>'; ?>
        <?php endforeach ?>
    </ul>
</div>
