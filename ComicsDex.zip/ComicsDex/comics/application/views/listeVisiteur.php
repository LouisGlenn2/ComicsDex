<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <link href="<?php echo base_url();?>application/views/bootstrap/css/bootstrap.min.css" rel="stylesheet">
        <script src="<?php echo base_url();?>application/views/bootstrap/js/bootstrap.min.js"></script>
        <link rel="stylesheet" type="text/css" href="<?php echo base_url();?>application/views/style.css">
        <title>Ajouter/Lister comics</title>
    </head>
       
       
    <body class="container-fluid">
            <div class="container-fluid header fixed-top">
               <div class="row">
                    <div>
                        <?php echo form_open('accueil/index') ?>
                        <input type="submit" value="Accueil" />
                        <?php echo form_close(); ?>
                    </div>

                    <?php echo form_open('accueil/connection') ?>
                        <input type="submit" value="Se connecter" />
                        <?php echo form_close(); ?>
                 </div>
               
            </div>
            <div class="main">
                <div class="row">
                        <?php foreach ($comic as $todo_item): 
                        echo '<div class="offset-1 carte2 row">';     
                
                        echo '<div>';
                            echo '<img src="'.$todo_item['couverture'].'"/>'; 
                        echo '</div>';
                        echo '<div>';
                            echo '';
                            echo '<div class="presentation">';
                                echo "<h3>".$todo_item['serie']."</h3>";
                                echo "<h4> Numero : ".$todo_item['numero']."</h4>";
                                echo "<h4> Date : ".$todo_item['date']."</h4>";
                            echo '</div>';
                       
                       ?>
                       </div>
                        <?php echo form_close();
                              echo '</div>'; ?>
                <?php endforeach ?>
            </div>
            <div class="container-fluid footer row">
                <strong>&copy;2019<br/>&copy;LOUIS Glenn<br/>&copy;GAUDIN Marius</strong>
                
            </div>  
    </body>
</html>
       
