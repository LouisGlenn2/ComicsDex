<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <link href="<?php echo base_url();?>application/views/bootstrap/css/bootstrap.min.css" rel="stylesheet">
        <script src="<?php echo base_url();?>application/views/bootstrap/js/bootstrap.min.js"></script>
        <link rel="stylesheet" type="text/css" href="<?php echo base_url();?>application/views/style.css">
        <title>Accueil</title>
    </head>
        <body>
            <?php     
                $this->load->helper('url');
                if(!($this->session->userdata('login'))){
                    redirect('Accueil/inscription');
                }
            ?>
            <div>
                <?php echo form_open('accueil/deconnexion') ?>
                <input type="submit" value="Déconnexion" />
                <?php echo form_close(); ?>
            </div>
            <div>
                <?php echo form_open('accueil/pageAjouterComics') ?>
                <input type="submit" value="Ajouter/Lister comics" />
                <?php echo form_close(); ?>
            </div>
            <?php if($this->session->userdata('login') == 'admin'){ ?>
                <?php echo '<div>'; ?>
                <?php echo form_open('accueil/adminAfficherUser'); ?>
                <input type="submit" value="Liste des utilisateurs" />
                <?php echo form_close(); 
                echo '</div>'; ?>
              <?php  }  
            ?>
            <ul>
                <?php foreach ($comic as $todo_item): ?>
                    <?php 
                        echo '<li> ';
                        echo form_open('accueil/supprimerComics');
                        echo $todo_item['comic_id']." ".$todo_item['serie']." ".$todo_item['numero']." ".$todo_item['date']." ".'<img class="photo" src="'.$todo_item['couverture'].'"/>' ?>
                        <input type="hidden" name="comic_id" value="<?php echo $todo_item['comic_id'] ?>">

                        <input type="submit" value="Supprimer" />
                        <?php echo form_close();
                          echo '</li>'; ?>
                <?php endforeach ?>
            </ul>
            
        </body>
            
</html>

