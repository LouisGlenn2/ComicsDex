<!DOCTYPE html>
<html> 
	<head>
		<meta charset = "utf-8" />
		<title>Collection comics</title> 
	</head>
	<body>

		<div id="global">

			<div id="entete">
				
				
			</div><!-- #entete -->
			
			<div id="contenu">
			
				<?php $this->load->view($content."/index"); ?>
					
			</div><!-- #contenu -->

			<div id="pied">
			
				<strong>&copy;2019<br/>&copy;LOUIS Glenn<br/>&copy;GAUDIN Marius</strong>
				
			</div><!-- #pied -->

		</div><!-- #global -->

	</body>
</html>
